
// JavaScript to handle the "Go Back" button click event
document.getElementById('goBackButton').addEventListener('click', function() {
    // Navigate back in the browser's history
    window.history.back();
});